﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Documentation", menuName = "Documentation/Any", order = 2)]
public class Any : Doc
{

}
