﻿using UnityEngine;


/// <summary>
/// Primitives are strings and numbers.
/// </summary>
[CreateAssetMenu(fileName = "Documentation", menuName = "Documentation/DocPrimitive", order = 2)]
public class DocPrimitive : Doc
{
}
