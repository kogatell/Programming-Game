﻿using UnityEngine;



public class Doc : ScriptableObject
{
    public string Name;
    public Type Type;
    public string Description;
}


