﻿
public enum Type 
{
    Array, Method, Number, String, HashMap
}
