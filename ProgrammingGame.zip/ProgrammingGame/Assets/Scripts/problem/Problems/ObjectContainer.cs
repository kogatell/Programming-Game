﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectContainer : ScriptableObject
{

    public virtual Object GetObject() { return Null.NULL; }

}
