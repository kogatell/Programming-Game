﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

public abstract class Object
{
    public abstract string Type();
    
    /// <summary>
    /// Returns if this object is an error
    /// </summary>
    /// <returns></returns>
    public bool IsError()
    {
        return Type() == Error.Name;
    }

    public Object ToNumber()
    {
        if (IsError()) return this;
        if (IsNumeric()) return this;
        if (Type() == Boolean.Name)
        {
            return ToBool() == Boolean.True ? new Number(1) : new Number(0);
        }
        if (Type() != String.Name) return new Error($"can't convert object of type {Type()} to numeric");
        try
        {
            return new Number(int.Parse((this as String).Value));
        }
        catch (Exception)
        {
            return new Error($"error converting string {this} to number");
        }
    }

    public Boolean ToBool()
    {
        if (Type() == Null.Name)
        {
            return Boolean.False;
        }

        if (Type() == Boolean.Name)
        {
            return this as Boolean;
        }
        
        return Boolean.True;
    }

    public bool IsNumeric()
    {
        return Type() == Number.Name;
    }

    public static Object FromJsonString(string json)
    {
        JObject parsedJson = JObject.Parse(json);
        JToken data = parsedJson["data"];
        
        return ObjectJSON.ParseJsonToken(data);
    }

    public virtual Object FromJson(JToken token) { return Null.NULL; }

    public virtual bool EqualDeep(Object target)
    {
        return target == this;
    }



}


class ObjectJSON
{
    public static Object ParseJsonToken(JToken token)
    {
        switch (token.Type)
        {
            case JTokenType.Array:
            {
                return new ArrayObject().FromJson(token);
            }

            case JTokenType.String:
            {
                return new String("").FromJson(token);
            }

            case JTokenType.Boolean:
            {
                return Boolean.FromBool(token.Value<bool>());
            }

            case JTokenType.Integer:
            {
                return new Number(token.Value<double>());
            }

            case JTokenType.Null:
            {
                return Null.NULL;
            }

            case JTokenType.Object:
            {
                return new Table().FromJson(token);
            }
        }

        return null;
    }
    
}